const para = document.querySelector("#text");

para.addEventListener("click", function () {
  para.style.fontSize = "50px";
  para.style.color = "yellow";
  para.style.backgroundColor = "blue";
});
